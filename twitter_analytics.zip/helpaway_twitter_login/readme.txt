=== Helpaway Twitter Analytics ===
Contributors: helpaway 
Tags: twitter, login, Twitter Analytics, twitter stastics, twitter follower, friends , tweets.
Donate link: https://www.helpaway.com/
Requires at least: 3.0
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Helpaway Twitter Connect is onle click, simple and easy to install. The Best part it it support V 1.1 and yes it is totally free.

== Description ==

Think of the world where we need to register in various site and you need to remember all the user name and password. this will lead to confusion worlds. so to overcome this social logins is made. Twitter login is made to overcome this scenario.  

Personally, I hate to fill out registration forms, waiting for confirmation e-mails, so we designed this plugin for our website. Now, we want to share this very usable plugin with everyone, for free!
 

* If your visitors have a Twitter profiles, they can perform the sign in with twitter in your site with a single click and can display the user information of the user on the website. the user information which is attached with the twitter account is retrived with sign in and displayed on the website. 

* Very simple to use.

* Fast and helpful support.

* Totally free.

#### Usage

After you activated the plugin, the plugin will autmatically 

#1 Create the table for you. the table can be found in the wordpress database.
   

#### Advanced usage


== Installation ==

1.  Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
2.  Create a Twitter app => https://dev.twitter.com/apps/new
3.  Choose an App Name, it can be anything you like. Fill out the description and your website home page with site_url
4.  Callback url must be:  siteurl/home.php 
5.  Give the read, write permission to apps creation.
6.  Accept the rules and Click on Create your twitter application
7.  Copy the  Consumer key and Consumer secret and past it in the wordpress->admin->twitter analytics  setting setion .
8.  Give the twitter user name and hit the sunbmit button in the wordpress->admin->twitter analytics section.
10. now copy the short code and paste it in the new post created.
11. Now you can see the user stastics on the page.



