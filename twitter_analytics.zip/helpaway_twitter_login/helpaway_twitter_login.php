<?php
/*
Plugin Name: Helpaway Twitter Analytics Plugin
Plugin URI: http://helpaway.com/
Description: The Twitter Analytics WordPress Plugin allows you to display your detailed Twitter Analytics in Wordpress Page, Post or Widget side bar. It displays number of Tweets, Followers, Mentions, ReTweets etc..
Author: Helpaway
Version: 1.0
Author URI:
*/

include_once 'twitter_analtics_plugin.php';
error_reporting(0);
// database connection
require_once ((dirname(dirname( dirname( dirname ( __FILE__ ) ))) )."/wp-config.php" );
require_once ((dirname(dirname( dirname( dirname ( __FILE__ ) ))) )."/wp-load.php");

// add css to the display page
function helpaway_twitter_login_account_css ()
{
	$twitter_css_url=plugins_url('assets/helpaway_twitter_login.css', __FILE__);
	echo "<link type=\"text/css\" rel=\"stylesheet\" href=\"" . $twitter_css_url ."\" />" . "\n";
}
add_action('wp_head',helpaway_twitter_login_account_css);

function helpaway_twitter_login ($content) {
	global $post;
	return $post->ID;
}
//display user data on the page

function helpaway_login_twitter_user_display ($namedetails)
{
    global $wpdb;
	$userdetails = $wpdb->get_row("SELECT * FROM wp_helpaway_twitter_user_statics where screename='".$namedetails."' order by id desc limit 0,1", OBJECT);
	$us_name='<a href="https://twitter.com/'.$userdetails->screename.'" target="_blank" ><h1>'.$userdetails->name.'</h1></a>';
	$home_screen_name='<a href="https://twitter.com/'.$userdetails->screename.'" target="_blank" ><h2>@'.$userdetails->screename.'</h2></a>';
	$user_imae_bigger=str_replace('_normal', $size, $userdetails->user_image);
	$homeimage = '<img src="'.$user_imae_bigger.'" height="108"  class="profile-pic"/>';
    $inserted  = date( "M d, Y",strtotime($userdetails->inserted)); 
	$user_details='<div class="middle-dashboardalert grid_10">
		<div class="profile">
		'.$homeimage.'
		'.$us_name.'
		'.$home_screen_name.'
		<p>'.$userdetails->user_decription.'</p>
		<p>'.ucwords($userdetails->location).'</p>
		<p>'.$userdetails->url.'</p>
		</div>
		<div class="dash-heading">Twitter Stats  as on    '.$inserted.'</div>
			<div class="tweet-container2">
				<table class="dashbaord" width="100%" border="" cellspacing="0" cellpadding="0">
				<tr>
				<td class="dashboard"><table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
				<td class="grid_title">tweets</td>
				<td class="grid_title">followers</td>
				<td class="grid_title">friends</td>
				<td class="grid_title">listing</td>
				<td class="grid_title">favourites</td>
				</tr>
				<tr class="grid even">
				<td class="grid_data">'.$userdetails->no_of_status.'</td>
				<td class="grid_data">'.$userdetails->no_of_follower.'</td>
				<td class="grid_data">'.$userdetails->no_of_friends.'</td>
				<td class="grid_data">'.$userdetails->no_of_listed.'</td>
				<td class="grid_data">'.$userdetails->favourites.'</td>
				</tr></table></td>
				</tr>
				</table>
			</div>
	</div>';
	return $user_details;

}

function helpaway_twitter_analytics_graph_draw ($namedetails)
{
	global $wpdb;
	$table_name4 = $wpdb->prefix . "helpaway_twitter_graph_data";
	$table_name2 = $wpdb->prefix . "helpaway_twitter_user_statics";
	$graph_table =$wpdb->get_row("SELECT * FROM ".$table_name4." where user_name='".$namedetails."'",OBJECT); 
	if (!empty($graph_table->id))
     $wpdb->delete($table_name4, array('user_name'=>$namedetails));

	$graph_table_user =$wpdb->get_row("SELECT no_of_follower FROM ".$table_name2." where screename='".$namedetails."' order by id desc limit 0,1",OBJECT);
	$counter=$graph_table_user->no_of_follower==''?0:$graph_table_user->no_of_follower;
    //insert in graph follower value
	
	for($k=0;$k<7;$k++)
	{
	$date_map=date ( "Y-m-d", mktime ( 0, 0, 0, date ( "m" ), date ( "d" ) - $k, date ( "Y" ) ) );
	$twitlistdata = $wpdb->get_row("SELECT no_of_follower,inserted FROM ".$table_name2." where screename='".$namedetails."' and inserted ='".$date_map."' order by id desc",OBJECT);
	$newdate=$twitlistdata->inserted;
	if($newdate==$date_map)
	    $counter= $twitlistdata->no_of_follower;
	else
		$dataar = array(
		'inserted'=>$date_map,
		'follower'=>$counter,
		'user_name'=>$namedetails,
		);
	
	$wpdb->insert($table_name4, $dataar);
	}
	///
	// retrive valuef from graph table.
	$maplinevalue='';
	$maplinevalue='[\'Date\',\'Followers\'],';
	$graphlistsort2 =$wpdb->get_results("SELECT inserted,follower FROM ".$table_name4." where user_name='".$namedetails."' order by inserted desc",OBJECT);
	for($i=5;$i>=0;$i--)
	{
	$date_map=$graphlistsort2[$i]->inserted;
	$date_map3=date( "M d",strtotime($date_map));
	$twitter_follower=$graphlistsort2[$i]->follower;
	$maplinevalue .='[\''.$date_map3.'\','.$twitter_follower.'],';
	}
	//
	$graph_value = substr($maplinevalue, 0, -1);
	$max_value   = $twitter_follower+10;
	$maxlinevalue='vAxis: {	maxValue: '.$max_value.',minValue:0, format:\'#\'},';
	
	$graph =' <div class="dash-heading">List of Followers</div>';
	$graph .='<script type=\'text/javascript\' src=\'https://www.google.com/jsapi\'></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
    	 var data = google.visualization.arrayToDataTable([
       '.$graph_value.'   ]);
        var options = {
        '.$maxlinevalue.'
          height:\'250\',
          width:\'550\',
          pointSize:10
        };
        var chart = new google.visualization.AreaChart(document.getElementById(\'chart_div_column\'));
        chart.draw(data, options);
      }
    </script>';
	$graph .='<div id="chart_div_column" style="margin:20px 10px;"></div>';
	return $graph; 
}

function helpaway_twitter_display_power_by ()
{
	$power_by ='<div id="powered">Powered by <a href="http://helpaway.com/" target="_blank">Helpaway.com</a>  </div>';
    return  $power_by;
}

//redirect to login page after first query
function helpaway_twitter_analytics_account_twitter ($namedetails,$oauth_access_token,$oauth_access_token_secret,$consumer_key,$consumer_secret)
{
	global $wpdb;
	$table_name2 = $wpdb->prefix . "helpaway_twitter_user_statics";
	$username = $wpdb->get_row("SELECT * FROM ".$table_name2." where screename='".$namedetails."'", OBJECT);
	if($username->id=='')
	{
	$url = "https://api.twitter.com/1.1/statuses/user_timeline.json";
	$parameter = array(
			'screen_name' =>$namedetails,
			'count' => 1,
			'include_entities' =>'true',
			'include_rts'      =>'true',
	);
	$paramu ='screen_name='.$namedetails.'&count=1&include_entities=true&include_rts=true';
	$type='GET';
	$contents= AnalyticsUsertwitterapi ($url, $parameter,$paramu,$oauth_access_token,$oauth_access_token_secret,$consumer_key,$consumer_secret,$type);
	$parsed = json_decode($contents, true);
	foreach ($parsed as $key => $value) {
		$datasar = array(
		            		'twitter_id' =>$parsed[$key]['user']['id_str'],
				  	    	'no_of_friends'=>$parsed[$key]['user']['friends_count'],
							'no_of_follower'=>$parsed[$key]['user']['followers_count'],
							'location'      =>$parsed[$key]['user']['location'],
							'name'          =>$parsed[$key]['user']['name'],
							'user_image'    =>$parsed[$key]['user']['profile_image_url'],
							'screename'     =>$parsed[$key]['user']['screen_name'],
							'user_decription'=> $parsed[$key]['user']['description'],
							'url'            =>$parsed[$key]['user']['url'],
							'no_of_listed'  =>$parsed[$key]['user']['listed_count'],
							'favourites'    =>$parsed[$key]['user']['favourites_count'],
							'no_of_status'  =>$parsed[$key]['user']['statuses_count'],
							'time_zone'     =>$parsed[$key]['user']['time_zone'],
							'inserted' =>date('Y-m-d'),
					);
	        		$wpdb->insert($table_name2, $datasar);
				}
							
	}
	
	
}
	
// hedaer setting.
function helpaway_login_account_twit()
{
	global $wpdb;
	$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";
	$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
	
	$twitter_config=$wpdb->get_row("select * from ".$table_name1." where id='1'",OBJECT);
	if ( empty($twitter_config->id ) )
	{
		echo '<div id="twitit">';
		echo ("Please go to admin setting page and insert the twitter configuration setting.");
		echo '</div>';

	}
	else
	{
		$consumer_key    =$twitter_config->consumer_key;
		$consumer_secret =$twitter_config->consumer_secret;
		$oauth_access_token    =$twitter_config->oauth_access;
		$oauth_access_token_secret =$twitter_config->oauth_secret;
		$twitter_analytics=$wpdb->get_row("select name from ".$table_name3." order by id desc limit 0,1",OBJECT);
       $namedetails=$twitter_analytics->name;
     	if(empty($namedetails))
		{
			echo '<div id="twitit">';
			echo ("Please go to admin setting page and insert the twitter user name in configuration setting.");
			echo '</div>';
		}	
		else
		{
        helpaway_twitter_analytics_account_twitter ($namedetails,$oauth_access_token,$oauth_access_token_secret,$consumer_key,$consumer_secret);
       echo  helpaway_login_twitter_user_display ($namedetails);
       echo helpaway_twitter_analytics_graph_draw ($namedetails);
	   echo helpaway_twitter_display_power_by ();	
     	}
	}
}


function helpaway_twitter_login_account_shortcode ()
{
	helpaway_login_account_twit ();
}

add_shortcode("helpaway_twitter_analytics","helpaway_twitter_login_account_shortcode");
// activate hook to create a table in the wordpress to store the twitter configuration data.
function helpaway_twitter_login_activate()
{
	global  $wpdb;
	$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name1 (
	id mediumint(9) NOT NULL AUTO_INCREMENT,
	oauth_access text NOT NULL,
	oauth_secret text NOT NULL,
	consumer_key text NOT NULL,
	consumer_secret text NOT NULL,
	UNIQUE KEY id (id)
	);";
	$wpdb->query($sql);
	$table_name2 = $wpdb->prefix . "helpaway_twitter_user_statics";
	
	$sql1 ="CREATE TABLE IF NOT EXISTS $table_name2 (
  id int(11) NOT NULL AUTO_INCREMENT,
  twitter_id varchar(250) DEFAULT '0',
  location varchar(500) DEFAULT NULL,
  no_of_follower int(100) NOT NULL DEFAULT '0',
  no_of_friends int(100) NOT NULL DEFAULT '0',
  inserted date NOT NULL,
  name varchar(500) DEFAULT NULL,
  screename varchar(500) DEFAULT NULL,
  user_image text,
  user_decription text,
  url text,
  no_of_listed bigint(250) DEFAULT NULL,
  favourites bigint(250) DEFAULT NULL,
  no_of_status bigint(250) DEFAULT NULL,
  time_zone varchar(500) DEFAULT NULL,
  PRIMARY KEY (id))";
	$wpdb->query($sql1);

  $table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
  $sql11="CREATE TABLE IF NOT EXISTS $table_name3 (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(250) DEFAULT NULL,
  PRIMARY KEY (id))";
 $wpdb->query($sql11);

 $table_name4 = $wpdb->prefix . "helpaway_twitter_graph_data";
 $sql4="CREATE TABLE IF NOT EXISTS $table_name4 (
 id int(11) NOT NULL AUTO_INCREMENT,
 follower bigint(250) DEFAULT NULL,
 user_name varchar(500) DEFAULT NULL,
 inserted date DEFAULT NULL,
 PRIMARY KEY (id))";
 $wpdb->query($sql4);
	
}
// deactive hook to delete table.
function helpaway_twitter_login_deactivate()
{
	global  $wpdb;
	$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";
	$table_name2 = $wpdb->prefix . "helpaway_twitter_user_statics";
	$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
	$table_name4 = $wpdb->prefix . "helpaway_twitter_graph_data";
	$sql = "DROP TABLE $table_name1;";
	$sql2 ="DROP TABLE $table_name2;";
	$sql3 ="DROP TABLE $table_name3;"; 
	$sql4 ="DROP TABLE $table_name4;";
	$wpdb->query($sql);
	$wpdb->query($sql2);
	$wpdb->query($sql3);
	$wpdb->query($sql4);
}
register_activation_hook( __FILE__, 'helpaway_twitter_login_activate' );
register_deactivation_hook(__FILE__, 'helpaway_twitter_login_deactivate' );
//admin section starts

// add css to admin
function helpaway_twitter_login_admin_css ()
{
	$admin_twitter_css =plugins_url('assets/helpaway_twitter_login_admin.css', __FILE__);
	echo '<link type="text/css" rel="stylesheet" href="' . $admin_twitter_css .'">';
}

add_action('admin_head', 'helpaway_twitter_login_admin_css');
add_action('admin_menu', 'helpaway_twitter_login_admin_menu');
function helpaway_twitter_login_admin_menu()
{
	add_menu_page("Twitter Analytics", "Twitter Analytics", 0, "twitter-analytics-menu-slug", "twitter_analytics_signin_page");
	add_submenu_page("twitter-analytics-menu-slug", "Analytics Setting", "Analytics Setting", 0, "twitter-analytics-submenu-slug", "twitter_analytics_Account_Setting_Page");
	add_submenu_page("twitter-analytics-menu-slug", "Cron Setting", "Cron Setting", 0, "twitter-analytics-crone-slug", "twitter_analytics_Account_crone_Page");
	add_submenu_page("twitter-analytics-menu-slug", "Statistics", "Statistics", 0, "twitter-analytics-preview-slug", "twitter_analytics_Preview_Page");
	add_submenu_page("twitter-analytics-menu-slug", "Analytics Guide", "Analytics Guide", 0, "twitter-analytics-guide-slug", "twitter_analytics_Account_Guide_Page");

}

function twitter_analytics_signin_page(){
	$admin_twitter_logo =plugins_url('assets/img/newsletter_logo.gif',__FILE__);
	$admin_intro ='<div class="wrapper-hlogin">

	<div class="header-hlogin">
	<h1 class="title-hlogin">Twitter Analytics Plugin</h1>
	</div>

	<div class="left-hlogin">

	<div class="welcome-hlogin">
	<h1>Twitter Analytics.</h1>
	<p>The Twitter Analytics WordPress Plugin allows you to display your detailed Twitter Analytics in Wordpress Page, Post or Widget side bar. It displays number of Tweets, Followers, Mentions, ReTweets etc. </p>
	</div>

	<div class="box-hlogin three-hlogin">
	<h1>Get Short Code</h1>
	<p>Display the plugin in any Post, Page, Template or Widget using the following shortcode.</p>
	<p>[helpaway_twitter_analytics]</p>
	</div>


	<div class="box-hlogin last-hlogin four-hlogin">
	<h1>Support</h1>
	<p>Need Support? For additional assistance or queries, please feel free to contact us.</p>
	</div>
	</div>
	<div class="right-hlogin">

	<div class="box2-hlogin">
	<a href="http://www.helpaway.com" /><img src="'.$admin_twitter_logo.'" class="logo-hlogin"/></a>
	<p>Helpaway.com is a Twitter based online Social Media Management Software to help businesses find new customers, assist existing clients & grow their Twitter presence.</p>

	<p><a href="http://www.helpaway.com">Contact Us</a> for more details</p>
	<p><iframe  frameborder="0" scrolling="no"
  src="//platform.twitter.com/widgets/follow_button.html?screen_name=helpaway"
  style="width:200px; height:20px;"></p>
	</div>
	</div>
	</div>';
	echo $admin_intro;
}

function twitter_analytics_Account_Setting_Page ()
{
	global $wpdb;
	$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";
	
	if(isset($_POST['consumerkey']))
	{
		if(!empty($_POST['consumerkey']) && !empty($_POST['consumersecret']) && !empty($_POST['accesstoken']) && !empty($_POST['accesstokensecret']))
		{
			$consumerkey       = $_POST['consumerkey'];
			$consumersecret    = $_POST['consumersecret'];
			$accesstoken       = $_POST['accesstoken'];
			$accesstokensecret = $_POST['accesstokensecret'];

			$datanew = array(
					'consumer_key'          =>$consumerkey,
					'consumer_secret'       =>$consumersecret,
					'oauth_access'          =>$accesstoken,
					'oauth_secret'          =>$accesstokensecret
			);
			$new_ent = $wpdb->get_row("select id from ".$table_name1." where id=1",OBJECT);
			if(empty($new_ent->id))
			$wpdb->insert($table_name1, $datanew);
			else
			$wpdb->update($table_name1, $datanew,array('id'=>1));	
		}
		else
			$twitter_error_login ='<p>Please Enter All field to be updated.</p>';
	}

	$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
	
	if(isset($_POST['username']))
	{
		if(!empty($_POST['username']))
		{
			$username = $_POST['username'];
	
			$datanew = array(
					'name'          =>$username,
			);
			$user_new=$wpdb->get_row("select name from ".$table_name3." where id=1",OBJECT);
			if(empty($user_new->name))
			$wpdb->insert($table_name3, $datanew);
			else
			$wpdb->update($table_name3, $datanew,array('id'=>1));
			$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
			
			$twitter_config=$wpdb->get_row("select * from ".$table_name1." where id='1'",OBJECT);
			if ( empty($twitter_config->id ) )
			{
				echo '<div id="twitit">';
				echo ("Please go to admin setting page and insert the twitter configuration setting.");
				echo '</div>';
			
			}
			else
			 {
				$consumer_key    =$twitter_config->consumer_key;
				$consumer_secret =$twitter_config->consumer_secret;
				$oauth_access_token    =$twitter_config->oauth_access;
				$oauth_access_token_secret =$twitter_config->oauth_secret;
			    helpaway_twitter_analytics_account_twitter ($username,$oauth_access_token,$oauth_access_token_secret,$consumer_key,$consumer_secret);
			  }
			}
	}
	
	
	$user_name=$wpdb->get_row("select name from ".$table_name3." order by id desc limit 0,1",OBJECT);
	$username_screenname =$user_name->name;
	$twitter_config=$wpdb->get_row("select * from ".$table_name1." order by id desc",OBJECT);
	$cons_key=$twitter_config->consumer_key;
	$cons_sec=$twitter_config->consumer_secret;
	$oauth_key=$twitter_config->oauth_access;
	$oauth_sec=$twitter_config->oauth_secret;
	
	$admin_twitter_logo =plugins_url('assets/img/newsletter_logo.gif',__FILE__);
	$twitter_login ='<div class="wrapper-hlogin">

	<div class="header-hlogin">
	<h1 class="title-hlogin">Twitter Analytics Settings</h1>
	</div>
	'.$twitter_error_login.'
	<div class="left-hlogin">

	<div class="twitter_login-hlogin">
	<h1>Twitter Application. </h1>
	<p> Create a Twitter application at Twitter and Configure your OAuth setup key. Get your Consume Key and access tokens by registering at - <a href="https://dev.twitter.com" target="_blank">https://dev.twitter.com/</a></p>
	<form method="post" action="#">
	<p>
	<label for="consumerkey">Consumer Key :</label>
	<input class="" id="consumerkey" name="consumerkey" type="text" value="'.$cons_key.'" />
	</p>
	<p>
	<label for="consumersecret">Consumer secret :</label>
	<input class="" id="consumersecret" name="consumersecret" type="text" value="'.$cons_sec.'" />
	</p>
	<p>
	<label for="accesstoken">Access token :</label>
	<input class="" id="accesstoken" name="accesstoken" type="text" value="'.$oauth_key.'" />
	</p>
	<p>
	<label for="accesstokensecret">Access token secret :</label>
	<input class="" id="accesstokensecret" name="accesstokensecret" type="text" value="'.$oauth_sec.'" />
	</p>
	<p>
	<input type="submit" class="button_twitter_login-adduser" value="Submit" />

	</p>
	</form>
	</div>
	
	<div class="twitter_login-hlogin">
	<h1>User Account to Analyze. </h1>
	<form method="post" action="#">
	<p>
	<label for="username">Twitter User Name :</label>
	<input class="" id="username" name="username" type="text" value="'.$username_screenname.'" />
	</p>
	<p>
	<input type="submit" class="button_twitter_login-adduser" value="Submit" />
	</p>
	</form>
	</div>


	</div>
	<div class="right-hlogin">

	<div class="box2-hlogin">
	<a href="http://www.helpaway.com" /><img src="'.$admin_twitter_logo.'" class="logo-hlogin"/></a>
	<p>Helpaway.com is a Twitter based online Social Media Management Software to help
	businesses find new customers, assist existing clients & grow their Twitter presence.</p>

	<p><a href="http://www.helpaway.com/contact-us">Contact Us</a> for more details</p>
	
	<p><iframe  frameborder="0" scrolling="no"
  src="//platform.twitter.com/widgets/follow_button.html?screen_name=helpaway"
  style="width:200px; height:20px;"></p>
	</div>
	</div>
	</div>';
	echo $twitter_login;

}

function twitter_analytics_Account_crone_Page ()
{
	$admin_twitter_logo =plugins_url('assets/img/newsletter_logo.gif',__FILE__);
	$crone_url = plugins_url('crone/user_crone.php',__FILE__);
	$guide ='<div class="wrapper-hlogin">
	
	<div class="header-hlogin">
	<h1 class="title-hlogin">Twitter Analytics Cron Setting</h1>
	</div>
	
	<div class="left-hlogin">
	
	<div class="welcome-hlogin">
	<p>To periodicaly update by crone you need to copy the link below and put it in the crone setting in your server. </p>
	<br />
	<p>
	'.$crone_url.'
	</p>
	</div>
	</div>
	<div class="right-hlogin">
	
	<div class="box2-hlogin">
	<a href="http://www.helpaway.com" /><img src="'.$admin_twitter_logo.'" class="logo-hlogin"/></a>
	<p>Helpaway.com is a Twitter based online Social Media Management Software to help
	businesses find new customers, assist existing clients & grow their Twitter presence.</p>
	
	<p><a href="http://www.helpaway.com/contact-us">Contact Us</a> for more details</p>
	<p><iframe  frameborder="0" scrolling="no"
  src="//platform.twitter.com/widgets/follow_button.html?screen_name=helpaway"
  style="width:200px; height:20px;"></p>
	</div>
	</div>
	
	</div>';
	echo $guide;
	
}

function twitter_analytics_Preview_Page ()
{
	global $wpdb;
	$admin_twitter_logo =plugins_url('assets/img/newsletter_logo.gif',__FILE__);
	$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";
	$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
	$twitter_analytics=$wpdb->get_row("select name from ".$table_name3." order by id desc limit 0,1",OBJECT);
	$namedetails=$twitter_analytics->name;
	$helpaway_preview = helpaway_login_twitter_user_display ($namedetails);
	$graph            = helpaway_twitter_analytics_graph_draw ($namedetails);
	$powerby          = helpaway_twitter_display_power_by ();
	$guide ='<div class="wrapper-hlogin">
	
	<div class="header-hlogin">
	<h1 class="title-hlogin">Twitter Analytics Statistics</h1>
	</div>
	
	<div class="left-hlogin">
	
	<div class="welcome2-hlogin">
	'.$helpaway_preview.'
	'.$graph.'
	'.$powerby.'
	</div>
	</div>
	<div class="right-hlogin">
	<div class="box2-hlogin">
	<a href="http://www.helpaway.com" /><img src="'.$admin_twitter_logo.'" class="logo-hlogin"/></a>
	<p>Helpaway.com is a Twitter based online Social Media Management Software to help
	businesses find new customers, assist existing clients & grow their Twitter presence.</p>
	<p><a href="http://www.helpaway.com/contact-us">Contact Us</a> for more details</p>
	<p><iframe  frameborder="0" scrolling="no"
	src="//platform.twitter.com/widgets/follow_button.html?screen_name=helpaway"
	style="width:200px; height:20px;"></p>
	</div>
	</div>
	</div>';
	echo $guide;
}

function twitter_analytics_Account_Guide_Page ()
{
	$admin_twitter_logo =plugins_url('assets/img/newsletter_logo.gif',__FILE__);
	
	$guide ='<div class="wrapper-hlogin">

	<div class="header-hlogin">
	<h1 class="title-hlogin">Twitter Analytics Guide</h1>
	</div>

	<div class="left-hlogin">

	<div class="welcome-hlogin">
<p>We perform the login with twitter and extract users information to be displayed. </p>
<br />
<p>
1.  User need to create an apps on the twitter. <br />
2.  User should prove the read write persmision to the apps.<br />
3.  Download the plugin.<br />
4.  Paste it in the wordpress plugin folder.<br />
5.  Activate the plugin from admin section.<br />
6.  Get the customer key, customer secret key, auth key and auth secret key.<br />
7.  Goto Analytic setting and fill all the field and hit the submit button.<br />
8.  put the twitter username whose account you want to track.
9.  Now get the short code from TwitterAnalytics page in admin section.<br />
10. Create a post and paste the short code.<br />
12. If you wish to have cron update for your status. copy the code given in crone sitting and paste it in the server and set your crone. <br />
13. Enjoy checking User analytics on the Twitter.<br />
    
 </p>
 </div>
</div>
	<div class="right-hlogin">

	<div class="box2-hlogin">
	<a href="http://www.helpaway.com" /><img src="'.$admin_twitter_logo.'" class="logo-hlogin"/></a>
	<p>Helpaway.com is a Twitter based online Social Media Management Software to help
	businesses find new customers, assist existing clients & grow their Twitter presence.</p>

	<p><a href="http://www.helpaway.com/contact-us">Contact Us</a> for more details</p>
	<p><iframe  frameborder="0" scrolling="no"
  src="//platform.twitter.com/widgets/follow_button.html?screen_name=helpaway"
  style="width:200px; height:20px;"></p>
	</div>
	</div>
	
	</div>';
	echo $guide;
}