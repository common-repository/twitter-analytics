<?php
include_once '../twitter_analtics_plugin.php';
require_once (dirname(dirname(dirname( dirname( dirname ( __FILE__ ) ))) )."/wp-config.php" );
require_once (dirname(dirname(dirname( dirname( dirname ( __FILE__ ) ))) )."/wp-load.php");


global $wpdb;
$table_name2 = $wpdb->prefix . "helpaway_twitter_user_statics";
$table_name3 = $wpdb->prefix . "helpaway_twitter_analtics_config";
$table_name1 = $wpdb->prefix . "helpaway_twitter_login_config";

$twitter_analytics=$wpdb->get_row("select name from ".$table_name3." order by id desc limit 0,1",OBJECT);
$namedetails=$twitter_analytics->name;

$twitter_config=$wpdb->get_row("select * from ".$table_name1." where id='1'",OBJECT);
if( !empty($twitter_config->id ) )
{
	$consumer_key    =$twitter_config->consumer_key;
	$consumer_secret =$twitter_config->consumer_secret;
	$oauth_access_token    =$twitter_config->oauth_access;
	$oauth_access_token_secret =$twitter_config->oauth_secret;
	
	$url = "https://api.twitter.com/1.1/statuses/user_timeline.json";
	$parameter = array(
			'screen_name' =>$namedetails,
			'count' => 1,
			'include_entities' =>'true',
			'include_rts'      =>'true',
	);
	$paramu ='screen_name='.$namedetails.'&count=1&include_entities=true&include_rts=true';
	$type='GET';
	$contents= AnalyticsUsertwitterapi ($url, $parameter,$paramu,$oauth_access_token,$oauth_access_token_secret,$consumer_key,$consumer_secret,$type);
	$parsed = json_decode($contents, true);
	foreach ($parsed as $key => $value) {
		$datasar = array(
				'twitter_id' =>$parsed[$key]['user']['id_str'],
				'no_of_friends'=>$parsed[$key]['user']['friends_count'],
				'no_of_follower'=>$parsed[$key]['user']['followers_count'],
				'location'      =>$parsed[$key]['user']['location'],
				'name'          =>$parsed[$key]['user']['name'],
				'user_image'    =>$parsed[$key]['user']['profile_image_url'],
				'screename'     =>$parsed[$key]['user']['screen_name'],
				'user_decription'=> $parsed[$key]['user']['description'],
				'url'            =>$parsed[$key]['user']['url'],
				'no_of_listed'  =>$parsed[$key]['user']['listed_count'],
				'favourites'    =>$parsed[$key]['user']['favourites_count'],
				'no_of_status'  =>$parsed[$key]['user']['statuses_count'],
				'time_zone'     =>$parsed[$key]['user']['time_zone'],
				'inserted' =>date('Y-m-d'),
		);
		$wpdb->insert($table_name2, $datasar);
	}
		
	

}